Users:
[
  {
    _id: new ObjectId('68778a2273fac3c6fc47790c'),
    name: 'test',
    email: 'test1@test.com',
    password: '$2a$10$WoQ3TU3VaKx82.kZQxWQLeJ0lMjqm0cn.6hxA28oENpwUO932nxta',
    avatar: '/tmp/a6f1c7bee41af66184d7fb4f3a8c3092',
    role: 'customer',
    createdAt: 2025-07-16T11:16:50.591Z,
    updatedAt: 2025-07-17T07:56:30.048Z,
    __v: 0
  },
  {
    _id: new ObjectId('688fdabac07035ae4c3779a9'),
    name: 'Customer 3',
    email: 'customer3@example.com',
    password: '$2a$10$3ub45JVYy6VPxfe54lkyU.y2/kO5Gwfeki5GbOqBmNEnltAV0FzgS',
    avatar: 'https://via.placeholder.com/150',
    role: 'customer',
    createdAt: 2025-08-03T21:55:06.336Z,
    updatedAt: 2025-08-03T21:55:06.336Z,
    __v: 0
  },
  {
    _id: new ObjectId('689d81eab4a2865a44756cfa'),
    name: 'Seed Seller',
    email: 'seed_seller_1755152874088@example.com',
    password: '$2a$10$0ONYZvPwRisfxtvAv7KzHeHAA2hpzhVSMvWz.HZJMgrfcONcoj/ES',
    avatar: 'https://via.placeholder.com/150',
    role: 'seller',
    createdAt: 2025-08-14T06:27:54.094Z,
    updatedAt: 2025-08-14T06:27:54.094Z,
    __v: 0
  },
  {
    _id: new ObjectId('689db309d1dfbebe055f1573'),
    name: 'testuser_1755165449127',
    email: 'test_1755165449127@example.com',
    password: '$2a$10$aBjfo.Qer2zNyndijHWtFe.m/sWRDPrXoBPksd8a98UWjstNs7hk2',
    avatar: 'https://via.placeholder.com/150',
    role: 'customer',
    createdAt: 2025-08-14T09:57:29.165Z,
    updatedAt: 2025-08-14T09:57:29.165Z,
    __v: 0
  }
]
Items:
[]