import { render } from '@testing-library/react';

// Simple smoke test
test('dummy test to ensure test suite runs', () => {
  expect(true).toBe(true);
});
